from . import res_company
from . import res_partner_zones
from . import res_partner_routes
