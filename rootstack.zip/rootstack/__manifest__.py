{
    'name': 'Rootstack',

    'version': '14.1.0.0',

    'author': "Luis Felipe Paternina",

    'contributors': ['Luis Felipe Paternina'],

    'website': "",

    'category': 'Reports',

    'depends': [

        'purchase',
        'sale_management',
        'hr',
        'contacts',
    ],

    'data': [
       
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/res_company.xml',
        'views/res_partner_route.xml',
        'views/res_partner_zone.xml',
        'reports/report_sale_order.xml',
        'data/sequences.xml',           
    ],
    'installable': True
}

